import { LightningElement } from 'lwc';

export default class HeadingComponent extends LightningElement {}